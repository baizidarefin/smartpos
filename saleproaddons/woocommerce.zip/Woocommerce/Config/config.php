<?php

return [
    'name' => 'Woocommerce'
];
