<section class="mb-3">
    <div class="container">
        <div class="row">
            <h2>{{$widget->text_title}}</h2>
            {!! $widget->text_content !!}
        </div>
    </div>
</section>