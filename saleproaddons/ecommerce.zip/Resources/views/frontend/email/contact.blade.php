<!doctype html>

<html lang="en">
	<body>
		<div>
			<p>Name: {{$data['name']}}</p>
			<p>email: {{$data['email']}}</p>
			<p>Phone: {{$data['phone']}}</p>
			<p>Message:</p>
			<p>{{$data['message']}}</p>
		</div>
	</body>
</html>