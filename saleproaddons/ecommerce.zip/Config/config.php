<?php

return [
    'name' => 'Ecommerce'
];
